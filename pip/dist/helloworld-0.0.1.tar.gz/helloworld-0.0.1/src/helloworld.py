def say_hello(name=None):
	if name is None:
		return "Hello, Wrld"

	else:
		return f"hello, {name}"